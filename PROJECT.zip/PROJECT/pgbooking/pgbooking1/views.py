from django.shortcuts import render

def home(request):
    return render(request, "pgbooking1/template/home.html")
