from django.apps import AppConfig


class Pgbooking1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pgbooking1'
